package com.amaid.glasswidgets

import android.content.Context
import android.hardware.ConsumerIrManager
import android.widget.Toast

/** Codes NEC 32 bits (adresse, ~adresse, commande, ~commande). */
object IrCodes {
    // LG : codes standard (adresse 0x04)
    val LG = mapOf(
        "power" to 0x20DF10EFL, "vol_up" to 0x20DF40BFL, "vol_down" to 0x20DFC03FL,
        "mute" to 0x20DF906FL, "ch_up" to 0x20DF00FFL, "ch_down" to 0x20DF807FL
    )
    // TCL : A VÉRIFIER sur ta télé (remplace par les codes de ton ancien widget si besoin)
    val TCL = mapOf(
        "power" to 0x40BF12EDL, "vol_up" to 0x40BF1AE5L, "vol_down" to 0x40BF1EE1L,
        "mute" to 0x40BF0DF2L, "ch_up" to 0x40BF1BE4L, "ch_down" to 0x40BF1FE0L
    )
}

object IrSender {
    fun send(ctx: Context, tv: String, key: String) {
        val ir = ctx.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        if (ir == null || !ir.hasIrEmitter()) {
            Toast.makeText(ctx, "Pas d'émetteur infrarouge", Toast.LENGTH_SHORT).show()
            return
        }
        val code = (if (tv == "TCL") IrCodes.TCL else IrCodes.LG)[key] ?: return
        ir.transmit(38000, nec(code))
    }

    private fun nec(code: Long): IntArray {
        val p = ArrayList<Int>()
        p.add(9000); p.add(4500)
        for (byteIdx in 0..3) {
            val b = ((code shr (24 - 8 * byteIdx)) and 0xFF).toInt()
            for (bit in 0..7) {
                p.add(560)
                p.add(if ((b shr bit) and 1 == 1) 1690 else 560)
            }
        }
        p.add(560)
        return p.toIntArray()
    }
}
